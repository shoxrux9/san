import test from 'node:test';import assert from 'node:assert/strict';import {mkdtempSync,rmSync} from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawn,spawnSync} from 'node:child_process';
test('Persistent catalog, authenticated administration and real order flow',async()=>{
 const data=mkdtempSync(path.join(os.tmpdir(),'sano-test-'));const port=31000+Math.floor(Math.random()*10000);const password='TestOnly-'+crypto.randomUUID();const env={...process.env,DATA_DIR:data,PORT:String(port),ADMIN_USER:'tester',ADMIN_PASSWORD:password};
 const setup=spawnSync(process.execPath,['scripts/create-admin.mjs'],{cwd:import.meta.dirname+'/..',env,encoding:'utf8'});assert.equal(setup.status,0,setup.stderr);
 let child;async function start(){child=spawn(process.execPath,['server.mjs'],{cwd:import.meta.dirname+'/..',env,stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Startup timeout')),10000);child.stdout.once('data',()=>{clearTimeout(timeout);resolve()});child.once('error',reject)})}
 let cookie='',csrf='';const request=async(p,method='GET',data,authorized=false)=>{const res=await fetch(`http://127.0.0.1:${port}${p}`,{method,headers:{'Content-Type':'application/json',...(authorized?{Cookie:cookie,'X-CSRF-Token':csrf}:{})},body:data===undefined?undefined:JSON.stringify(data)});return {res,data:await res.json()}};
 try{await start();let r=await request('/api/books');assert.equal(r.res.status,200);assert.equal(r.data.length,111);const book=r.data[0];assert.equal((await request('/api/admin/orders')).res.status,401);
 r=await request('/api/login','POST',{user:'tester',password});assert.equal(r.res.status,200);cookie=r.res.headers.get('set-cookie').split(';')[0];csrf=r.data.csrf;
 assert.equal((await request('/api/admin/orders','GET',undefined,true)).res.status,200);
 const edited={...book,price:25000,stock:3};assert.equal((await request('/api/admin/records/books/'+book.id,'PUT',edited,true)).res.status,200);
 const payload={key:crypto.randomUUID(),name:'Test Customer',phone:'+998901234567',delivery:'pickup',items:[{id:book.id,quantity:2}]};r=await request('/api/orders','POST',payload);assert.equal(r.res.status,201);const order=r.data.id;
 assert.equal((await request('/api/orders','POST',payload)).data.id,order);r=await request('/api/admin/orders','GET',undefined,true);assert.equal(r.data.length,1);assert.equal(r.data[0].total,50000);
 assert.equal((await request('/api/orders','POST',{...payload,key:crypto.randomUUID(),items:[{id:book.id,quantity:4}]})).res.status,409);
 assert.equal((await request('/api/admin/records/books/'+book.id,'PUT',{...edited,status:'hidden'},true)).res.status,200);assert.equal((await request('/api/orders','POST',{...payload,key:crypto.randomUUID()})).res.status,409);
 assert.equal((await request('/api/books')).data.some(b=>b.id===book.id),false);
 r=await fetch(`http://127.0.0.1:${port}/api/admin/records/books/${book.id}`,{method:'PUT',headers:{'Content-Type':'application/json',Cookie:cookie},body:JSON.stringify(edited)});assert.equal(r.status,403);
 assert.equal((await request('/api/admin/upload','POST',{data:Buffer.from('<svg onload="alert(1)">').toString('base64')},true)).res.status,400);
 await request('/api/admin/records/books/'+book.id,'PUT',{record:{...edited,title:'Unpublished title'},saveDraft:true},true);r=await request('/api/admin/records/books/'+book.id,'GET',undefined,true);assert.equal(r.data.draft.title,'Unpublished title');assert.notEqual(r.data.record.title,'Unpublished title');
 child.kill();await new Promise(r=>child.once('exit',r));await start();r=await request('/api/admin/orders','GET',undefined,true);assert.equal(r.data[0].id,order);assert.equal(r.data[0].items[0].title,book.title);
 console.log('PASS: 111 books, authentication, CSRF, order persistence, idempotency, stock validation, hidden-book rejection, draft isolation, upload restriction.');
 }finally{if(child){child.kill();await new Promise(r=>child.once('exit',r))}rmSync(data,{recursive:true,force:true})}
});
