"""Public-source content importer. pip install beautifulsoup4 pillow"""
import json, urllib.request, urllib.parse, hashlib, concurrent.futures, time, re
from pathlib import Path
from bs4 import BeautifulSoup
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]; MEDIA=ROOT/'public/media';MEDIA.mkdir(exist_ok=True)
BASE='https://sano.uz/'
errors=[]; assets={}
def fetch(url):
 for attempt in range(3):
  try:
   return urllib.request.urlopen(urllib.request.Request(url.replace('http://sano.uz','https://sano.uz'),headers={'User-Agent':'Mozilla/5.0'}),timeout=35).read()
  except Exception as e:
   if attempt==2: errors.append({'url':url,'error':str(e)});return b''
 return b''
def soup(url):return BeautifulSoup(fetch(url),'html.parser')
def asset(url):
 if not url:return ''
 url=urllib.parse.urljoin(BASE,url)
 if url in assets:return assets[url]
 suffix=Path(urllib.parse.urlparse(url).path).suffix.lower()
 if suffix not in ['.jpg','.jpeg','.png','.webp','.gif']:return ''
 name=hashlib.sha256(url.encode()).hexdigest()[:20]+suffix;p=MEDIA/name
 if not p.exists():
  data=fetch(url)
  if not data:return ''
  p.write_bytes(data)
  try:
   with Image.open(p) as im: im.verify()
  except Exception: p.unlink(missing_ok=True);return ''
 assets[url]='/media/'+name;return assets[url]
def text(el):return el.get_text(' ',strip=True) if el else ''
def product(url):
 s=soup(url); title=s.select_one('h1.product_title')
 if not title:return None
 image=s.select_one('.woocommerce-product-gallery img, .images img')
 desc=s.select_one('#tab-description, #group-description .content')
 if desc:
  for e in desc.select('h2'):e.decompose()
 name=text(title); body=text(desc)
 meta={}
 for row in s.select('.tovar tr'):
  cells=row.select('td')
  if len(cells)>=2:meta[text(cells[-2])]=text(cells[-1])
 cat=text(s.select_one('.posted_in'))
 return {'id':hashlib.sha256(url.encode()).hexdigest()[:12],'source':url,'title':name,'author':meta.get('Автор',''),'description':{'uz':body,'ru':body,'en':body},'image':asset(image.get('data-large_image') or image.get('src')) if image else '', 'category':cat.replace('Категории:','').replace('Категория:','').strip() or 'Kitoblar','language':'','price':None,'stock':None,'status':'published','orderable':True,'featured':False,'isbn':meta.get('ISBN',''),'pages':meta.get('Страница',''),'format':meta.get('Формат',''),'binding':text(s.select_one('.tagged_as')).replace('Метка:','').strip(),'year':meta.get('Год',''),'translationReview':True}
def listing(page):
 url=BASE+('?page_id=249' if page==1 else '?post_type=product&paged='+str(page));s=soup(url)
 return [urllib.parse.urljoin(BASE,a['href']) for a in s.select('li.product a.woocommerce-LoopProduct-link,li.product a.woocommerce-loop-product__link')]
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex: links=list(dict.fromkeys(u for rows in ex.map(listing,range(1,11)) for u in rows))
 print('Discovered',len(links),flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex: books=[b for b in ex.map(product,links) if b]
 for b in books[:8]:b['featured']=True
 (ROOT/'data/books.json').write_text(json.dumps(books,ensure_ascii=False,indent=2))
 print('Imported',len(books),flush=True)
 pages=[];equipment=[];certificates=[];partners=[]
 for pid,key in [(190,'home'),(1015,'about'),(105,'services'),(184,'certificates'),(186,'contacts')]:
  u=BASE+'?page_id='+str(pid);s=soup(u); content=s.select_one('.entry-content')
  pages.append({'key':key,'source':u,'text':text(content)})
  if key=='certificates':
   for a in s.select('a[href]'):
    if '/uploads/' in a['href'] and re.search(r'\.(jpg|png|jpeg)$',a['href'],re.I):certificates.append({'id':'cert'+str(len(certificates)), 'title':{'uz':'Sertifikat '+str(len(certificates)+1),'ru':'Сертификат '+str(len(certificates)+1),'en':'Certificate '+str(len(certificates)+1)},'image':asset(a['href']),'source':a['href'],'visible':True})
 home=soup(BASE)
 logo=home.select_one('#logo');logo_url=asset(logo.get('src')) if logo else ''
 for a in home.select('a[href]'):
  if re.search(r'\?p=\d+',a['href']):
   if a['href'] in [e['source'] for e in equipment]:continue
   s=soup(a['href']);c=s.select_one('.entry-content');im=c.select_one('img') if c else None
   if not im:
    for ha in home.select('a[href]'):
     if ha['href']==a['href'] and ha.select_one('img'):
      im=ha.select_one('img');break
   equipment.append({'id':'equipment'+str(len(equipment)),'title':{'uz':text(s.select_one('h1')),'ru':text(s.select_one('h1')),'en':text(s.select_one('h1'))},'body':{'uz':text(c),'ru':text(c),'en':text(c)},'image':asset(im.get('src')) if im else '', 'source':a['href'],'visible':True})
 # Preserve remaining homepage images in an asset manifest for admin reuse.
 for im in home.select('img[src]'):asset(im['src'])
 (ROOT/'data/legacy.json').write_text(json.dumps({'pages':pages,'equipment':equipment,'certificates':certificates,'logo':logo_url,'assets':assets},ensure_ascii=False,indent=2))
 (ROOT/'data/migration-report.json').write_text(json.dumps({'source':BASE,'expectedCatalogCount':111,'discovered':len(links),'imported':len(books),'missing':max(0,111-len(books)),'assets':len(assets),'errors':errors,'notes':['Unknown prices and stock retained as null.','Original descriptions retained; translations require editorial review.','Legacy contacts and certificate validity require owner review.']},ensure_ascii=False,indent=2))
 print('Done assets',len(assets),'errors',len(errors),flush=True)
